"""Tests for Apple TV."""
import pytest

# Make asserts in the common module display differences
pytest.register_assert_rewrite("tests.components.apple_tv.common")
